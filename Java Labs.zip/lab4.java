import java.util.Scanner;

public class lab4 {
	
	public static void main(String[] args) {
		
		Scanner information= new Scanner (System.in);
		
		System.out.print("Enter 2 points coordinates: x1 y1 x2 y2? ");
		int x1 = information.nextInt();
		int y1 = information.nextInt();
		int x2 = information.nextInt();
		int y2 = information.nextInt();
		
		if(x1 == 0 && x2 == 0) {
			System.out.println("The two points are on the Y-axis.");
		}
		else if (x1 > 0 && x2 > 0) {
			System.out.println("The two points are on the right to the Y-axis.");
			if(y1 < 0 || y2 < 0) {
				System.out.println("Point1 is on the second quadrant!");
			}
		}
		else if (x1 < 0 && x2 < 0) {
			System.out.println("The two points are on the left to the Y-axis.");
			if(y1 > 0 || y2 > 0) {
				System.out.println("Point2 is on the fourth quadrant!");
			}
		}
		
		double xy = ((x2 - x1)*(x2 - x1)) + ((y2 - y1)*(y2 - y1));
		double d = Math.sqrt(xy);
		System.out.println("The distance between the two points is "+ d +" cm.");
		
		information.close();
		
	}
}
