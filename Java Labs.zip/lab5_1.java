import java.util.Scanner;
public class lab5_1 {
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner (System.in);
		
		System.out.print("Enter the base and the exponent: ");
		int x = scanner.nextInt();
		int y = scanner.nextInt();
		
		System.out.println("Your exponentiation expression has a base "+x+" and an exponent "+y+".");
		
		int result = (int)Math.pow(x,y);
		
		if(x>y) {
			System.out.println("The base is greater than the expoent.");
		}
		else if (x<y) {
			System.out.println("The base is smaller than the exponent.");
		}
		
		System.out.println("the result of "+x+ " raised to the power of "+y+ " is " + result+ "." +
				"\nWoW!");
		scanner.close();
	}
}
