import java.util.Scanner;

public class lab1{
	
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter the time(minutes) you have been reading followed by");
		int time = scan.nextInt();
		
		System.out.println("your average speed reading (WPM: words per minute):");
		int speed = scan.nextInt();
		
	
		double result = time*speed;
		double p = result/500;
		
		System.out.println("You have been reading for "+time+ " minutes with a speed reading of "+speed+ " WPM.");
		System.out.println("You have read "+p+ " page(s).");
		
		scan.close();
	}
}
