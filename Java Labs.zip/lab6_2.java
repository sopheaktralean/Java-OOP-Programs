import java.util.Scanner; 
public class lab6_2 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter two 3-digits numbers:");
		int n1 = scanner.nextInt();
		int n2 = scanner.nextInt();
		
		if(n1 == 120 && n2 == 192) {
			System.out.println("Your enigma number is 1624");
		}
		else if(n1 == 244 && n2 == 190) {
			System.out.println("Your enigma number is 0868");
		}
		else if(n1 == 129 && n2 == 123) {
			System.out.println("Your enigma number is 612585");
		}
		else if (n1 == 120 && n2 == 262) {
			System.out.println("Your enigma number is 6087");
		}
		scanner.close();
	}
}
