import java.util.Scanner;


public class lab2 {

	public static void main(String[] args) {
		
		Scanner information = new Scanner(System.in);
		
		int A = 3;
		int B = 5; 
		int C = 7;
	
		
		System.out.println("The value of X:");
		int X = information.nextInt();
		
		int L = (X*X)%A + 2*(B*X)/C;
		System.out.println("With the value of X equals to "+X+" the result of the expression is " +L + ".");
		
		
		information.close();
	}

}
