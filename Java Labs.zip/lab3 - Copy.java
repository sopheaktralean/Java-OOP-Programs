import java.util.Scanner;

public class lab3 {
	public static void main(String[] args) {
		
		Scanner information = new Scanner(System.in);
		
		System.out.println("Enter 3 points coordinates: x1 y1 x2 y2 x3 y3?");
		int x1 = information.nextInt(); 
		int y1 = information.nextInt();
		int x2 = information.nextInt();
		int y2 = information.nextInt();
		int x3 = information.nextInt();
		int y3 = information.nextInt();
		
		if (y1 == y2 && y2 == y3 && x1 >= 0 && x2 >= 0 && x3 >= 0) {
			System.out.println("The three points lie on a line parallel to X-axis on the right side.");
		}
		else if (y1 == y2 && y2 == y3 && x1 <= 0 && x2 <= 0 && x3 <= 0) {
			System.out.println("The three points lie on a line parallel to X-axis on the left side.");
		}
		else {
			System.out.println("The three points do not lie on a line parallel to X-axis or left/right side.");
		}
	
		information.close();
	}
}
