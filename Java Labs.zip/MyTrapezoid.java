
/*	COPYRIGHT OF CONCORDIA UNIVERSITY
DEPARTMENT OF ENGINEERING AND COMPUTER SCIENCE

	COMP248 F2023

	Topic: Simple Class
	PROF: Nora Houari
	 
*/

import java.util.Scanner;

public class MyTrapezoid{

	// ------------------------
	// CODE TO COMPLETE
	// -------------------------

	// Declare instance variable
	private int a;
	private int b;
	private int c;
	private int B;
	private int h;

	// --------------------------------------------
	// TWO GIVEN Constructors You Should not modify
	// --------------------------------------------

	// A default constructor
	public MyTrapezoid() {
	}

	//Attributes
	public MyTrapezoid(int n1, int n2, int n3, int n4, int n5) {
		this.a = n1;
		this.b = n2;
		this.c = n3;
		this.B = n4;
		this.h = n5;
	}

	// ------------------------
	// CODE TO COMPLETE
	// -------------------------

	// Implement Get methods
	public int getA() {
		return a;
		
	}
	public int getB() {
		return b;
	}
	public int getC() {
		return c;
	}
	public int getBase() {
		return B;
	}
	public int getH() {
		return h;
	}
	
	public void setA(int n1) {
		a = n1;
	}
	public void setb(int n2) {
		b = n2;
	}
	public void setC(int n3) {
		c = n3;
	}
	public void setB(int n4) {
		B = n4;
	}
	public void setH(int n5) {
		h = n5;
	}
	
	public void ReadData() {
	}
	
	public void DisplayData(int a, int b, int c, int B, int h){
		System.out.println("MyTrapzoid object has four sides a, b, c, B: " + a + " " + b + " " + c + " "+ B + " and a height of " + h);
	}
	public int TraPerimeter(int a, int b, int c, int B) {
		return (a+b+c+B);	
	}
	public double TraArea(double h, double B, double b)
	{
		return (1/2)*(h*(B+b));
	}
	public boolean AreEven(int TraPerimeter, double TraArea) {
		return (TraPerimeter % 2 == 0 && TraArea % 2 == 0);
		
	}
	// Implement AreEven method
	/*
	 * =============================================================================
	 * =====================
	 */
	 /*
	 * =====*****-----+++++!!!!! DO NOT ALTER, CHANGE, OR MODIFY THE CODE BELOW *
	 * 		 * !!!!!+++++-----*****=====
	 */
	/*
	 * =============================================================================
	 * 		 * =====================
	 */
	public static void main(String[] args) {

		Scanner keyIn = new Scanner(System.in);
			int perimeter = 0;
			double area = 0.0;
			boolean type;

		MyTrapezoid objTra = new MyTrapezoid();
			objTra.ReadData();
			int n1 = objTra.getA();
			int n2 = objTra.getB();
			int n3 = objTra.getC();
			int n4 = objTra.getBase();
			int n5 = objTra.getH();

		System.out.println("Enter ther four sides and the height of the trapezoid? ");
		n1 = keyIn.nextInt();
		n2 = keyIn.nextInt();
		n3 = keyIn.nextInt();
		n4 = keyIn.nextInt();
		n5 = keyIn.nextInt();
		
		//System.out.println("MyTrapezoid object has four sides a, b, c, B: "+ a+ b + c + B+ "and a height of "+ h);
		
		objTra.DisplayData();

		perimeter = objTra.TraPerimeter(n1, n2, n3, n4);
		area = objTra.TraArea(n2, n4, n5);

		System.out.println("The perimeter of MyTrapezoid object is: " + perimeter);
		System.out.println("The area of MyTrapezoid object is: " + area);

		type = objTra.AreEven(perimeter, area);
		System.out.print("Are the perimeter and area MyTrapezoid object both even (true or false)? " + type);

		keyIn.close();
		}
	}

