import java.util.Scanner;

public class lab5_2 {
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the input: ");
		int x = scanner.nextInt();
		
		if (x % 2== 0) {
			System.out.println(x + " is an even integer.");
		}
		else if (x % 2== 1) {
			System.out.println(x+ " is an odd integer.");
		}
		
		int fact = 1;
		for(int i = 1; i <= x; i++) {
			fact = fact*i;
		}
		System.out.println("The factorial value of x is "+ fact+ ".");
		scanner.close();
	}
}
