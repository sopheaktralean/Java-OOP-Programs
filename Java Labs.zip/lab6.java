import java.util.Scanner;

public class lab6 {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter two 3-digits numbers:");	
		int n1 = scanner.nextInt();
		int n2 = scanner.nextInt(); 
		int doubleSum = (2*(n1 + n2));
		
		if(((doubleSum % 3) == 0) && ((doubleSum % 7) != 0))
		{
			String enigma = "1"+ doubleSum;
			System.out.println("Your enigma number is " + enigma);
		}
		else if (((doubleSum % 3) != 0) &&  ((doubleSum % 7) == 0))
		{
			String enigma1 ="0" + doubleSum;
			System.out.println("Your enigma number is " + enigma1);
		}
		else if (((doubleSum % 3) == 0) && ((doubleSum % 7) == 0)){
			System.out.println("Your enigma number is " + (n2/2)+(n1*2)+5);
		}
		else if (((doubleSum % 3) != 0) && ((doubleSum % 7) != 0)) {
			System.out.println("Your enigma number is " + (n1/2)+ (n2/3));
		}
			
		scanner.close();
	}
}
