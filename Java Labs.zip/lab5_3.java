import java.util.Scanner;

public class lab5_3 {

	public static void main (String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("Please enter the input: ");
		int number = scanner.nextInt();
		int num = number; 
		int reversenum = 0;
		
		while (num != 0) {
			int digit = num%10;
			reversenum = reversenum*10 + digit; 
			num = num/10;
		}
		System.out.println("The reversed order of "+ number+ " is " +reversenum);
		scanner.close();
	}
}
