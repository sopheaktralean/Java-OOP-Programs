import java.util.Scanner; 
public class lab7 {
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter array size (at least 5)? ");
		int size = scanner.nextInt();
		
		char[] array = new char[size];
		
		System.out.print("Enter "+size+ " distinct characters to store in the array: ");
		for(int i = 0; i < size; i++) {
			array[i] = scanner.next().charAt(0);
		}
		
		System.out.println();
		System.out.println("The array entered: ");
		for(char ch : array) {
			System.out.print(ch+ "\t" );
		}
		
		System.out.print("\nEnter the value you want to insert into position 3: ");
		char replace = scanner.next().charAt(0);
		
		for(int i = size - 1; i > 3; i--) {
			array[i] = array[i-1];
		}
		array[3] = replace;
		
		System.out.println(replace + " will be entered at position 3 into the array.");
		System.out.println("Array after insertion:");
		for(char ch: array) {
			System.out.print(ch+ "\t");
		}
		scanner.close();
	}
}