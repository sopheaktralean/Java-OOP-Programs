import java.util.Scanner;

public class lab5 {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter your game score? ");
		int score= scanner.nextInt();
		
		if(score == 2 || score ==3 || score == 5 || score == 7 ||score == 17) {
			System.out.println("My score is a prime number: I am happy!");
		}
		else {
			System.out.println("My score is not a prime number: I need to change strategy!");
		}
		scanner.close();
	}
}
